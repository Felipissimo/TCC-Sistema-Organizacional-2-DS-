CLIMATIZE - PROJETO SIMPLES

TECNOLOGIAS:
- HTML
- CSS
- JavaScript puro

Não usa React, Bootstrap, banco de dados ou API.

ACESSO GESTOR:
Email: gestor@escola.com
Senha: 123456

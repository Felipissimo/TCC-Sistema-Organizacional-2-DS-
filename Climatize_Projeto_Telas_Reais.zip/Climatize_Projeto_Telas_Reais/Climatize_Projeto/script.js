var perguntas = [
    "O ambiente de trabalho é respeitoso e colaborativo",
    "A comunicação interna é clara e eficiente",
    "Tenho os recursos necessários para realizar meu trabalho",
    "Sinto que meu trabalho é reconhecido",
    "Tenho boas oportunidades de desenvolvimento",
    "A liderança está aberta para ouvir os funcionários",
    "Existe equilíbrio entre trabalho e vida pessoal",
    "Sinto-me seguro para dar minha opinião",
    "As decisões da empresa são comunicadas de forma clara",
    "Eu recomendaria esta empresa como um bom lugar para trabalhar"
];

var notas = [];

function esconderTudo() {
    document.getElementById("telaPesquisa").classList.add("escondido");
    document.getElementById("telaQuestionario").classList.add("escondido");
    document.getElementById("telaGestor").classList.add("escondido");
    document.getElementById("telaDashboard").classList.add("escondido");
}

function mostrarInicio() {
    esconderTudo();
    document.getElementById("telaPesquisa").classList.remove("escondido");
}

function mostrarPesquisa() {
    esconderTudo();
    document.getElementById("telaQuestionario").classList.remove("escondido");
    criarPerguntas();
}

function mostrarGestor() {
    esconderTudo();
    document.getElementById("telaGestor").classList.remove("escondido");
}

function criarPerguntas() {
    var area = document.getElementById("perguntas");
    area.innerHTML = "";

    for (var i = 0; i < perguntas.length; i++) {
        var notaInicial = notas[i] || 6;

        area.innerHTML +=
            '<div class="pergunta-card">' +
                '<div class="pergunta-titulo">' +
                    '<span>' + (i + 1) + '. ' + perguntas[i] + '</span>' +
                    '<span class="rosto">😐</span>' +
                '</div>' +
                '<input class="range" type="range" min="0" max="10" value="' + notaInicial + '" oninput="mudarNota(' + i + ', this.value)">' +
                '<div class="numeros"><span>0<br><small>Insatisfeito</small></span><span>1</span><span>2</span><span>3</span><span>4</span><span>5<br><small>Satisfeito</small></span><span>6</span><span>7</span><span>8</span><span>9</span><span>10<br><small>Muito satisfeito</small></span></div>' +
                '<div class="nota" id="nota' + i + '">' + notaInicial + '</div>' +
                '<div class="satisfacao" id="textoNota' + i + '">' + textoNota(notaInicial) + '</div>' +
            '</div>';
    }

    atualizarProgresso();
}

function mudarNota(indice, valor) {
    notas[indice] = Number(valor);
    document.getElementById("nota" + indice).innerText = valor;
    document.getElementById("textoNota" + indice).innerText = textoNota(Number(valor));
    atualizarProgresso();
}

function textoNota(nota) {
    if (nota <= 3) return "😟 Insatisfeito";
    if (nota <= 6) return "😐 Satisfeito";
    if (nota <= 8) return "🙂 Satisfeito";
    return "😄 Muito satisfeito";
}

function atualizarProgresso() {
    var respondidas = 0;

    for (var i = 0; i < perguntas.length; i++) {
        if (notas[i] != null) respondidas++;
    }

    if (respondidas == 0) respondidas = 1;

    document.getElementById("numeroPergunta").innerText = respondidas + " de 10";
    document.getElementById("barraProgresso").style.width = (respondidas * 10) + "%";
}

function enviarPesquisa() {
    var total = 0;

    for (var i = 0; i < perguntas.length; i++) {
        if (notas[i] == null) notas[i] = 6;
        total += notas[i];
    }

    var media = (total / 10).toFixed(1);

    alert("Pesquisa enviada com sucesso!\\nSua média registrada foi: " + media);
    mostrarInicio();
}

function entrarGestor() {
    var email = document.getElementById("emailGestor").value;
    var senha = document.getElementById("senhaGestor").value;
    var erro = document.getElementById("erroLogin");

    if (email == "gestor@escola.com" && senha == "123456") {
        erro.innerText = "";
        esconderTudo();
        document.getElementById("telaDashboard").classList.remove("escondido");
    } else {
        erro.innerText = "Email ou senha incorretos.";
    }
}

function sairDashboard() {
    mostrarInicio();
}

function menuDashboard(botao) {
    var botoes = document.getElementsByClassName("menu-item");

    for (var i = 0; i < botoes.length; i++) {
        botoes[i].classList.remove("ativo");
    }

    botao.classList.add("ativo");
}

function mostrarAviso(botao) {
    menuDashboard(botao);
    alert("Esta tela está representada no protótipo. A funcionalidade completa será desenvolvida posteriormente.");
}
